function addTokens(input, tokens){
    if(typeof input!='string')
    {console.log("Input should be a string")
    throw "Invalid input"
    }

    if(input.length<6)
    {
        console.log("Input should have at least 6 characters")
        throw "Input should have at least 6 characters"
    }

    if(!Array.isArray(tokens))
    {
        console.log("Invalid array format")
        throw "Invalid array format"
    }

    let ok=1;
    for(let i=0;i<tokens.length;i++)
        if( typeof tokens[i].tokenName!="string") ok=0;
    if(ok==0)
        throw "Invalid array format"

        if (input.indexOf("...") == -1) {
            console.log(input);
            return input;
          }
         
    
        else{
            let j=0;
            while(input.includes("...")==true)
            {
                input = input.replace("...", "${" + tokens[j].tokenName + "}");
                j++;
            }
            console.log(input)
            return input
        }    

}

const app = {
    addTokens: addTokens
}

module.exports = app;